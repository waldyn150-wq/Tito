package com.wali.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF101C33)
private val Blue = Color(0xFF315CBA)
private val Pale = Color(0xFFF3F6FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WaliApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WaliApp() {
    var message by remember { mutableStateOf("") }
    var approval by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var messages by remember { mutableStateOf(listOf("مرحباً! أنا WALI AI، مساعدك الشخصي. كيف أقدر أساعدك اليوم؟")) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Pale)) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("WALI AI", fontWeight = FontWeight.Bold, color = Navy)
                            Text("مساعدك الشخصي الذكي", fontSize = 11.sp, color = Color.Gray)
                        }
                    },
                    actions = { IconButton(onClick = { showSettings = !showSettings }) { Icon(Icons.Default.Settings, "الإعدادات") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            },
            bottomBar = {
                Surface(color = Color.White, shadowElevation = 8.dp) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = message,
                            onValueChange = { message = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("اكتب رسالتك هنا...") },
                            shape = RoundedCornerShape(22.dp),
                            maxLines = 3
                        )
                        Spacer(Modifier.width(6.dp))
                        IconButton(onClick = { if (message.isNotBlank()) { messages = messages + "أنت: $message" + "وصلت رسالتك. ربط الذكاء الاصطناعي سيُفعّل في مرحلة الإعداد التالية."; message = "" } }) {
                            Icon(Icons.Default.Send, "إرسال", tint = Blue)
                        }
                        IconButton(onClick = { messages = messages + "ميزة الصوت قيد التجهيز." }) { Icon(Icons.Default.Mic, "الصوت", tint = Blue) }
                    }
                }
            },
            containerColor = Pale
        ) { padding ->
            if (showSettings) {
                Column(Modifier.padding(padding).fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("الإعدادات", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Navy)
                    FeatureRow(Icons.Default.Email, "Gmail", "بانتظار تفعيل الربط داخل التطبيق")
                    FeatureRow(Icons.Default.CalendarMonth, "التقويم", "بانتظار تفعيل الربط داخل التطبيق")
                    FeatureRow(Icons.Default.Lock, "حماية الموافقات", "لن ينفذ التطبيق أي إجراء خارجي مؤثر دون موافقتك")
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("طلب موافقة قبل الإجراءات الخارجية", Modifier.weight(1f))
                        Switch(checked = approval, onCheckedChange = { approval = it })
                    }
                    Text("ملاحظة: هذا إصدار تأسيسي للواجهة؛ التكاملات الفعلية والاتصال الهاتفي لم تُفعّل بعد.", color = Color.Gray, fontSize = 13.sp)
                    Button(onClick = { showSettings = false }) { Text("رجوع للمحادثة") }
                }
            } else {
                Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
                    Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(62.dp).background(Blue, CircleShape), contentAlignment = Alignment.Center) {
                                Text("W", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.height(10.dp))
                            Text("أهلاً بيك في WALI AI", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text("مساعدك لتنظيم يومك وإدارة أعمالك", color = Color(0xFFD5DDF0), fontSize = 13.sp)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("مركز المساعد", color = Navy, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        QuickTile("البريد", Icons.Default.Email, Modifier.weight(1f))
                        QuickTile("التقويم", Icons.Default.CalendarMonth, Modifier.weight(1f))
                        QuickTile("الموافقات", Icons.Default.CheckCircle, Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("المحادثة", color = Navy, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(messages) { item ->
                            Surface(color = Color.White, shape = RoundedCornerShape(16.dp), shadowElevation = 1.dp) {
                                Text(item, Modifier.fillMaxWidth().padding(14.dp), color = Navy, textAlign = TextAlign.Start)
                            }
                        }
                    }
                    Text("الإجراءات الخارجية تتطلب موافقتك الصريحة.", Modifier.fillMaxWidth().padding(top = 8.dp), textAlign = TextAlign.Center, color = Color.Gray, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun FeatureRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Surface(color = Color.White, shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Blue)
            Spacer(Modifier.width(12.dp))
            Column { Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, fontSize = 12.sp, color = Color.Gray) }
        }
    }
}

@Composable
private fun QuickTile(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Surface(modifier = modifier.height(82.dp), color = Color.White, shape = RoundedCornerShape(16.dp), shadowElevation = 1.dp) {
        Column(Modifier.fillMaxSize().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = Blue)
            Spacer(Modifier.height(5.dp))
            Text(title, fontSize = 12.sp, color = Navy, fontWeight = FontWeight.Medium)
        }
    }
}
